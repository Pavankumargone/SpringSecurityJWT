package com.pavan.service;

import com.pavan.entity.UserInfo;

public interface UserInfoService {
	public String addUser(UserInfo userInfo);
}
